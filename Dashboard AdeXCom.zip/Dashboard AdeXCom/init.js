angular.module('dashboard', [])
    .controller("dashboard", function ($scope,dashboardFactory) {
        dashboardFactory.fetchData('sidebarData').then(function(data){
            $scope.sideBarItems = data;

        }, function(data){
            console.error("Data not found");
        });

        dashboardFactory.fetchData('visitorsProgressData').then(function(data){
            $scope.visitorProgressData = data;

        }, function(data){
            console.error("Data not found");
        });
    });
    