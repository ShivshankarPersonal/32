angular.module('dashboard')
    .directive('progressChart', function () {
        return {
            restrict: 'E',
            template: '<div id="progressChart"></div>',
            controller: function () {
                var createGradient=function(svg,id,color1,color2){
                    var defs = svg.append("svg:defs");
                    var red_gradient = defs.append("svg:linearGradient")
                        .attr("id", id)
                        .attr("x1", "0%")
                        .attr("y1", "0%")
                        .attr("x2", "50%")
                        .attr("y2", "100%")
                        .attr("spreadMethod", "pad");
                    red_gradient.append("svg:stop")
                        .attr("offset", "50%")
                        .attr("stop-color", color1)
                        .attr("stop-opacity", 1);
                    red_gradient.append("svg:stop")
                        .attr("offset", "100%")
                        .attr("stop-color", color2)
                        .attr("stop-opacity", 1);
                };
                var percent = 60;
                var ratio=percent/100;
                var pie=d3.pie()
                    .value(function(d){return d})
                    .sort(null);
                var w=300,h=300;
                var outerRadius=(w/2)-10;
                var innerRadius=110;
                var color = ['rgb(185,207,0)','rgb(220, 247, 9)','rgb(244,244,244)'];
                var svg=d3.select("#progressChart")
                    .append("svg")
                    .attrs({
                        width:w,
                        height:h,
                        class:'shadow'
                    }).append('g')
                    .attrs({
                        transform:'translate('+w/2+','+h/2+')'
                    });
                createGradient(svg,'gradient',color[0],color[1]);
                var arc=d3.arc()
                    .innerRadius(innerRadius)
                    .outerRadius(outerRadius)
                    .startAngle(0)
                    .endAngle(2*Math.PI);

                var arcLine=d3.arc()
                    .innerRadius(innerRadius)
                    .outerRadius(outerRadius)
                    .startAngle(0);
                var pathBackground=svg.append('path')
                    .attrs({
                        d:arc
                    })
                    .styles({
                        fill:color[2]
                    });
                var pathChart=svg.append('path')
                    .datum({endAngle:0})
                    .attrs({
                        d:arcLine
                    })
                    .styles({
                        fill:'url(#gradient)'
                    });
                var middleCount=svg.append('text')
                    .text(function(d){
                        return d;
                    })
                    .attrs({
                        class:'middleText',
                        'text-anchor':'middle',
                        dy:30,
                        dx:-15
                    })
                    .styles({
                        fill:color[0],
                        'font-size':'90px'
                    });
                svg.append('text')
                    .text('%')
                    .attrs({
                        class:'percent',
                        'text-anchor':'middle',
                        dx:50,
                        dy:-5
                    })
                    .styles({
                        fill:color[0],
                        'font-size':'40px'
                    });
                var arcTween=function(transition, newAngle) {
                    transition.attrTween("d", function (d) {
                        var interpolate = d3.interpolate(d.endAngle, newAngle);
                        var interpolateCount = d3.interpolate(0, percent);
                        return function (t) {
                            d.endAngle = interpolate(t);
                            middleCount.text(Math.floor(interpolateCount(t)));
                            return arcLine(d);
                        };
                    });
                };
                var animate=function(){
                    pathChart.transition()
                        .duration(750)
                        .call(arcTween,((2*Math.PI))*ratio);
                };
                setTimeout(animate,0);
            }
        }
    });
